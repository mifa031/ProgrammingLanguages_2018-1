#pragma once

#include "afxwin.h"
#include <list>

using namespace std;

class IntermediateToPostfix {
private:
	list<CString> inter_list;
	CString temp_inter;
	CString postfix;
	char* err_num_str[9];
	int operand_num;
	int operator_num;
	int paran_num;
	
public:
	int err_num;
	bool noop;
	IntermediateToPostfix();
	IntermediateToPostfix(list<CString>& inter);
	void make_postfix();
	bool isPush(CString inter_str); // push �����ΰ�?
	bool isCon(CString inter_str);  // ����ΰ�?
	bool isVar(CString inter_str);  // �����ΰ�?
	bool isOp(CString inter_str);   // �������ΰ�?
	CString getPostfix();
};