
#include "stdafx.h"
#include "MyToy.h"
#include "MyFunc.h"
#include <cstring>
#include <cstdio>
#include <cstdlib>

