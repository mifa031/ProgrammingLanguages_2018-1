import javax.swing.JOptionPane;

public class BasicMessageBox extends Thread{
	String message;
	
	BasicMessageBox(String message){
		this.message = message;
	}
	
	@Override
	public void run() {
		JOptionPane.showMessageDialog(null, message);
	}
}
