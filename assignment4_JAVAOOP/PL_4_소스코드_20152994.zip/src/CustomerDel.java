import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.swing.JOptionPane;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class CustomerDel implements Runnable{
	private JSONObject cObj;
	private JSONArray cArr;
	
	public CustomerDel(int cNum){
		cObj = new JSONObject();
		
		cObj.put("cNum", cNum);
		cObj.put("cName", "");
		cObj.put("cTel", "");
		cObj.put("cBirth", "");
		cObj.put("cDate", "");
		cObj.put("cAccum", 0);
		JSONArray tempArr = new JSONArray();
		cObj.put("cOrders", tempArr);
		
		cArr = new JSONArray();
	}
	
	public void delete(){
		boolean isExist = false;
		try{
		JSONParser parser = new JSONParser();
		File f = new File("custom.txt");
		
		if(f.isFile()){
			FileReader reader = new FileReader(f);
			int readed = reader.read();
			if(readed == 0 || readed == -1){
				throw new MyException("������ ������ ������ �����ϴ�.",9);
			}else{
				String json = new String(Files.readAllBytes(Paths.get("custom.txt")));
				JSONObject fObj = (JSONObject) parser.parse(json);
				JSONArray fArr = (JSONArray) fObj.get("customers");
				for(int i=0; i<fArr.size(); i++){
					JSONObject jsonObj = new JSONObject();
					jsonObj = (JSONObject)fArr.get(i);
					cArr.add(jsonObj);
					if(jsonObj.get("cNum").toString().equals(cObj.get("cNum").toString())){
						isExist = true;
						cArr.remove(jsonObj);
						Thread t = new BasicMessageBox(jsonObj.get("cNum").toString()+"�� ���� ������ �����߽��ϴ�.");
						t.start();
					}
				}
				if(isExist){
					JSONObject customers = new JSONObject();
					customers.put("customers", cArr);
					FileWriter writer = new FileWriter(f);
					writer.write(customers.toJSONString());
					writer.flush();
					writer.close();
				}else{ // ã�� ���� ������ �������� �ʴ� ���
					throw new MyException("ã�� ���������� �����ϴ�.",5);
				}
				
			}
		}else{
			throw new MyException("�˻��� ������ �����ϴ�.",8); 
		}
		}catch(MyException e){
			Thread t = new WarningMessageBox(e.getMessage());
			t.start();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void run() {
		delete();
	}

}
