import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.json.simple.*;

import javax.swing.JTabbedPane;
import javax.swing.BoxLayout;
import javax.swing.JTextField;
import java.awt.FlowLayout;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import com.jgoodies.forms.factories.FormFactory;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.AbstractListModel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.awt.event.ActionEvent;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;


public class MainFrame extends JFrame {
	JSONObject customObj;
	JSONArray customArr;
	private JPanel contentPane;
	private JTextField textField_date_A;
	private JTextField textField_cnum_A;
	private JTextField textField_cnum_B;
	private JTextField textField_cname_B;
	private JTextField textField_tel_B;
	private JTextField textField_date_B;
	private JTextField textField_birth_B;
	private JComboBox comboBox_menu_A;
	
	private Integer cNum;
	private String sNum;
	private String cName;
	private String cTel;
	private String cBirth;
	private String cDate;
	private String oDate;
	private String oMenu;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame frame = new MainFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainFrame() {
		customObj = new JSONObject();
		customArr = new JSONArray();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.X_AXIS));
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		contentPane.add(tabbedPane);
		
		JPanel panel_1 = new JPanel();  // �ֹ����� �� ����
		tabbedPane.addTab("\uC8FC\uBB38\uAD00\uB9AC", null, panel_1, null);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("\uB0A0\uC9DC");
		lblNewLabel_1.setToolTipText("");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(42, 38, 72, 15);
		panel_1.add(lblNewLabel_1);
		
		textField_date_A = new JTextField();
		textField_date_A.setFont(new Font("����", Font.PLAIN, 13));
		lblNewLabel_1.setLabelFor(textField_date_A);
		textField_date_A.setBounds(139, 33, 162, 25);
		panel_1.add(textField_date_A);
		textField_date_A.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("\uACE0\uAC1D\uBC88\uD638");
		lblNewLabel_2.setToolTipText("");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(42, 77, 72, 15);
		panel_1.add(lblNewLabel_2);
		
		textField_cnum_A = new JTextField();
		textField_cnum_A.setFont(new Font("����", Font.PLAIN, 13));
		lblNewLabel_2.setLabelFor(textField_cnum_A);
		textField_cnum_A.setBounds(139, 72, 162, 25);
		panel_1.add(textField_cnum_A);
		textField_cnum_A.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("\uBA54\uB274");
		lblNewLabel_3.setToolTipText("");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(42, 122, 72, 15);
		panel_1.add(lblNewLabel_3);
		
		JButton btnNewButton_order_A = new JButton("\uC8FC\uBB38");  // �ֹ���ư
		btnNewButton_order_A.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					validateFormatA();
					
					OrderNew order = new OrderNew(cNum, oMenu, oDate);
					Thread t1 = new Thread(order);
					t1.start();
					
					t1.join();
					
					Thread t2 = new CouponSend(order);
					t2.start();
				} catch (MyException e) {
					JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		});
		btnNewButton_order_A.setBounds(102, 178, 97, 34);
		panel_1.add(btnNewButton_order_A);
		
		JButton btnNewButton_cancel_A = new JButton("\uC8FC\uBB38\uCDE8\uC18C"); // �ֹ���� ��ư
		btnNewButton_cancel_A.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					validateFormatA();
					OrderCancel cancel = new OrderCancel(cNum, oDate,oMenu);
					Thread t = new Thread(cancel);
					t.start();
				} catch (MyException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
				
			}
		});
		btnNewButton_cancel_A.setBounds(234, 178, 97, 34);
		panel_1.add(btnNewButton_cancel_A);
		
		comboBox_menu_A = new JComboBox();
		lblNewLabel_3.setLabelFor(comboBox_menu_A);
		comboBox_menu_A.setModel(new DefaultComboBoxModel(new String[] {"\uAE40\uBC25", "\uB5A1\uBCF6\uC774", "\uC21C\uB300", "\uC624\uB385", "\uD280\uAE40"}));
		comboBox_menu_A.setBounds(139, 119, 162, 21);
		panel_1.add(comboBox_menu_A);
		
		JPanel panel_2 = new JPanel();  // �������� �� ����
		tabbedPane.addTab("\uACE0\uAC1D\uAD00\uB9AC", null, panel_2, null);
		panel_2.setLayout(null);
		
		textField_cnum_B = new JTextField();
		textField_cnum_B.setFont(new Font("����", Font.PLAIN, 13));
		textField_cnum_B.setBounds(156, 10, 162, 25);
		panel_2.add(textField_cnum_B);
		textField_cnum_B.setColumns(10);
		
		textField_cname_B = new JTextField();
		textField_cname_B.setFont(new Font("����", Font.PLAIN, 13));
		textField_cname_B.setBounds(156, 44, 162, 25);
		panel_2.add(textField_cname_B);
		textField_cname_B.setColumns(10);
		
		textField_tel_B = new JTextField();
		textField_tel_B.setFont(new Font("����", Font.PLAIN, 13));
		textField_tel_B.setBounds(156, 79, 162, 25);
		panel_2.add(textField_tel_B);
		textField_tel_B.setColumns(10);
		
		textField_birth_B = new JTextField();
		textField_birth_B.setBounds(156, 114, 162, 25);
		textField_birth_B.setFont(new Font("����", Font.PLAIN, 13));
		panel_2.add(textField_birth_B);
		textField_birth_B.setColumns(10);
		
		textField_date_B = new JTextField();
		textField_date_B.setFont(new Font("����", Font.PLAIN, 13));
		textField_date_B.setBounds(156, 145, 162, 25);
		panel_2.add(textField_date_B);
		textField_date_B.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("\uACE0\uAC1D\uBC88\uD638");
		lblNewLabel_4.setLabelFor(textField_cnum_B);
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(55, 15, 72, 15);
		panel_2.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("\uACE0\uAC1D\uBA85");
		lblNewLabel_5.setLabelFor(textField_cname_B);
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setBounds(55, 49, 72, 15);
		panel_2.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("\uC804\uD654\uBC88\uD638");
		lblNewLabel_6.setLabelFor(textField_tel_B);
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setBounds(55, 84, 72, 15);
		panel_2.add(lblNewLabel_6);
		
		JLabel lblNewLabel_8 = new JLabel("\uAC00\uC785\uC77C");
		lblNewLabel_8.setLabelFor(textField_date_B);
		lblNewLabel_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_8.setBounds(55, 150, 72, 15);
		panel_2.add(lblNewLabel_8);
		
		JLabel lblNewLabel_7 = new JLabel("\uC0DD\uC77C");
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7.setBounds(55, 117, 72, 15);
		panel_2.add(lblNewLabel_7);
		lblNewLabel_7.setLabelFor(textField_birth_B);
		
		JButton btnNewButton_add_B = new JButton("\uACE0\uAC1D\uB4F1\uB85D"); // ������� ��ư
		btnNewButton_add_B.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
					validateFormatB();
					CustomerEnroll enroll = new CustomerEnroll(cNum,cName,cTel,cBirth,cDate);
					Thread t = new Thread(enroll);
					t.start();
				}catch(MyException e){
					JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
				
			}
		});
		btnNewButton_add_B.setBounds(0, 180, 92, 32);
		panel_2.add(btnNewButton_add_B);
		
		JButton btnNewButton_search_B = new JButton("\uACE0\uAC1D\uAC80\uC0C9"); // �����˻� ��ư
		btnNewButton_search_B.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					validateFormatB();

					CustomerSearch search = new CustomerSearch(cNum);
					ExecutorService service = Executors.newFixedThreadPool(1);
					Future<JSONObject> future = service.submit(search);				

					customObj = future.get();
					textField_cnum_B.setText(customObj.get("cNum").toString());
					textField_cname_B.setText(customObj.get("cName").toString());
					textField_tel_B.setText(customObj.get("cTel").toString());
					textField_date_B.setText(customObj.get("cDate").toString());
					textField_birth_B.setText(customObj.get("cBirth").toString());
					
				} catch(MyException e){
					JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				} catch (InterruptedException e) {
					e.printStackTrace();
				} catch (ExecutionException e) {
					JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
					textField_cnum_B.setText(cNum.toString());
					textField_cname_B.setText("");
					textField_tel_B.setText("");
					textField_date_B.setText("");
					textField_birth_B.setText("");
				}
			}
		});
		btnNewButton_search_B.setBounds(104, 180, 92, 32);
		panel_2.add(btnNewButton_search_B);
		
		JButton btnNewButton_del_B = new JButton("\uACE0\uAC1D\uC0AD\uC81C");  // �������� ��ư
		btnNewButton_del_B.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					validateFormatB();
					CustomerDel del = new CustomerDel(cNum);
					Thread t = new Thread(del);
					t.start();
					textField_cname_B.setText("");
					textField_tel_B.setText("");
					textField_birth_B.setText("");
					textField_date_B.setText("");
				} catch (MyException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
				
			}
		});
		btnNewButton_del_B.setBounds(327, 180, 92, 32);
		panel_2.add(btnNewButton_del_B);
		
		JButton btnNewButton_new_B = new JButton("\uC0C8\uACE0\uAC1D"); // ������ ��ư
		btnNewButton_new_B.addActionListener(new ActionListener() {  
			public void actionPerformed(ActionEvent e) {
				textField_cnum_B.setText("");
				textField_cname_B.setText("");
				textField_tel_B.setText("");
				textField_birth_B.setText("");
				textField_date_B.setText("");
			}
		});
		btnNewButton_new_B.setBounds(208, 180, 92, 32);
		panel_2.add(btnNewButton_new_B);
	}
	
	public void validateFormatA() throws MyException{
		boolean isNum;
		
		if(textField_cnum_A.getText().isEmpty() &&                  
	       textField_date_A.getText().isEmpty()){
			throw new MyException("�Էµ� ������ �����ϴ�.",6);    // �Է¶� ���� ���� üũ
		}
		
		
		try{
			cNum = Integer.parseInt(textField_cnum_A.getText());
			isNum = true;
		}catch(NumberFormatException n){
			sNum = textField_cnum_A.getText();
			isNum = false;
		}
		oDate = textField_date_A.getText();
		oMenu = comboBox_menu_A.getSelectedItem().toString();
		
		boolean flag_date_odate;
		Pattern date_pat = Pattern.compile("(^[0-9\\/]*$)");
		Matcher m_date_odate = date_pat.matcher(oDate);
		flag_date_odate = m_date_odate.find();
		
		boolean flag_sp_num, flag_sp_menu;
		Pattern special_pat = Pattern.compile("(^[0-9a-zA-Z��-�R]*$)"); // Ư������ ���� üũ
		Matcher m_snum;
		if(isNum == true){
			m_snum = special_pat.matcher(cNum.toString());
		}else{
			m_snum = special_pat.matcher(sNum);
		}
		Matcher m_smenu = special_pat.matcher(oMenu);
		flag_sp_num = m_snum.find();
		flag_sp_menu = m_smenu.find();
		
		if(!flag_date_odate){
			throw new MyException("�ֹ����� ��¥ ������ ���� �ʽ��ϴ�.",1);
		}
		
		if(!flag_sp_num || !flag_sp_menu){
			throw new MyException("�Է� �� �߿� Ư�����ڰ� �����մϴ�.",3);
		}
		
		if(!isNum){
			throw new MyException("������ȣ�� ���ڰ� �ƴմϴ�.",7);
		}
		
	}
	
	public void validateFormatB() throws MyException{
		boolean isNum;
		try{
			cNum = Integer.parseInt(textField_cnum_B.getText());
			isNum = true;
		}catch(NumberFormatException n){
			sNum = textField_cnum_B.getText();
			isNum = false;
		}
		cName = textField_cname_B.getText();
		cTel = textField_tel_B.getText();
		cBirth = textField_birth_B.getText();
		cDate = textField_date_B.getText();
		boolean flag_date_birth;
		boolean flag_date_cdate;
		boolean flag_ctel;
		boolean flag_special;
		
		Pattern tel_pat = Pattern.compile("(^[0-9\\-]*$)");  // ��ȭ��ȣ�� ��¥ ���� üũ
		Pattern date_pat = Pattern.compile("(^[0-9\\/]*$)");
		Matcher m_ctel = tel_pat.matcher(cTel);
		Matcher m_date_birth = date_pat.matcher(cBirth);
		Matcher m_date_cdate = date_pat.matcher(cDate);		
		flag_ctel = m_ctel.find();
		flag_date_birth = m_date_birth.find();
		flag_date_cdate = m_date_cdate.find();
		
		boolean flag_sp_num, flag_sp_name;
		Pattern special_pat = Pattern.compile("(^[0-9a-zA-Z��-�R]*$)"); // Ư������ ���� üũ
		Matcher m_snum;
		if(isNum == true){
			m_snum = special_pat.matcher(cNum.toString());
		}else{
			m_snum = special_pat.matcher(sNum);
		}
		Matcher m_sname = special_pat.matcher(cName);
		flag_sp_num = m_snum.find();
		flag_sp_name = m_sname.find();

		
		if(textField_cnum_B.getText().isEmpty() &&                   
		   textField_cname_B.getText().isEmpty() &&
		   textField_tel_B.getText().isEmpty() &&
		   textField_birth_B.getText().isEmpty() &&
		   textField_date_B.getText().isEmpty()){
		   throw new MyException("�Էµ� ������ �����ϴ�.",6);    // �Է¶� ���� ���� üũ
		}
		if(!flag_ctel || !flag_date_birth || !flag_date_cdate ){
			if(!flag_ctel){
				JOptionPane.showMessageDialog(null, "��ȭ��ȣ ������ ���� �ʽ��ϴ�.", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			if(!flag_date_birth){
				JOptionPane.showMessageDialog(null, "������ ��¥ ������ ���� �ʽ��ϴ�.", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			if(!flag_date_cdate){
				JOptionPane.showMessageDialog(null, "�������� ��¥ ������ ���� �ʽ��ϴ�.", "Error", JOptionPane.ERROR_MESSAGE);
			}
			throw new MyException("��ȭ��ȣ �Ǵ� ��¥�� �ٽ� �Է����ּ���.",1);
		}
		if(!flag_sp_num || !flag_sp_name){
			throw new MyException("�Է� �� �߿� Ư�����ڰ� �����մϴ�.",3);
		}
		if(!isNum){
			throw new MyException("������ȣ�� ���ڰ� �ƴմϴ�.",7);
		}
		if(cName.length() >= 10){
			throw new MyException("10�� �̻��� �̸��� �Է��� �� �����ϴ�.",4);
		}

	}
}
