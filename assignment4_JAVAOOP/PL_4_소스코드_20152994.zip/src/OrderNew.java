import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;

import javax.swing.JOptionPane;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class OrderNew implements Runnable{
	public Integer cNum;
	private String oMenu;
	private String oDate;
	private JSONObject cObj;
	private JSONArray cArr;
	public int cAccum = -1;
	
	public OrderNew(int cNum, String oMenu, String oDate){
		this.cNum = cNum;
		this.oMenu = oMenu;
		this.oDate = oDate;
	}
	
	public void order(){
		boolean isExist = false;
		try{
		JSONParser parser = new JSONParser();
		File f = new File("custom.txt");
		
		if(f.isFile()){
			FileReader reader = new FileReader(f);
			int readed = reader.read();
			if(readed == 0 || readed == -1){
				throw new MyException("������ ������ ������ �����ϴ�.",9);
			}else{
				String json = new String(Files.readAllBytes(Paths.get("custom.txt")));
				JSONObject fObj = (JSONObject) parser.parse(json);
				JSONArray fArr = (JSONArray) fObj.get("customers");
				for(int i=0; i<fArr.size(); i++){
					JSONObject jsonObj = new JSONObject();
					jsonObj = (JSONObject)fArr.get(i);
					if(jsonObj.get("cNum").toString().equals(cNum.toString())){
						isExist = true;
						Integer tempAccum = Integer.parseInt(jsonObj.get("cAccum").toString());
						if(tempAccum < 3){
							((HashMap) fArr.get(i)).replace("cAccum",tempAccum+1);
							cAccum = tempAccum+1;
						}else{
							((HashMap) fArr.get(i)).replace("cAccum",0);
							cAccum = 0;
						}

						JSONObject tempObj = new JSONObject();
						tempObj.put("oMenu", oMenu);
						tempObj.put("oDate", oDate);
						JSONArray tempArr = new JSONArray();
						tempArr = (JSONArray) jsonObj.get("cOrders");
						tempArr.add(tempObj);
						((HashMap) fArr.get(i)).replace("cOrders",tempArr);
						Thread t = new BasicMessageBox(jsonObj.get("cNum").toString()+"�� ������ �ֹ�����\n"+oMenu+"\n"+oDate);
						t.start();
					}
				}
				
				if(!isExist){ // ã�� ���� ������ �������� �ʴ� ���
					throw new MyException("ã�� ���������� �����ϴ�.",5);
				}else{
					JSONObject customers = new JSONObject();
					customers.put("customers", fArr);
					FileWriter writer = new FileWriter(f);
					writer.write(customers.toJSONString());
					writer.flush();
					writer.close();
				}
				
			}
					
		}else{
			throw new MyException("�˻��� ������ �����ϴ�.",8);
		}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (MyException e) {
			Thread t = new WarningMessageBox(e.getMessage());
			t.start();
		}
	}
	
	public void modifyAccum(int cAccum){
		this.cAccum = cAccum;
		
		try{
			JSONParser parser = new JSONParser();
			File f = new File("custom.txt");
			String json = new String(Files.readAllBytes(Paths.get("custom.txt")));
			JSONObject fObj = (JSONObject) parser.parse(json);
			JSONArray fArr = (JSONArray) fObj.get("customers");
		
			for(int i=0; i<fArr.size(); i++){
				JSONObject jsonObj = new JSONObject();
				jsonObj = (JSONObject)fArr.get(i);
				if(jsonObj.get("cNum").toString().equals(cNum.toString())){
					((HashMap) fArr.get(i)).replace("cAccum",cAccum);
				}
			}
		
			JSONObject customers = new JSONObject();
			customers.put("customers", fArr);
			FileWriter writer = new FileWriter(f);
			writer.write(customers.toJSONString());
			writer.flush();
			writer.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void run() {
		order();
	}

}
