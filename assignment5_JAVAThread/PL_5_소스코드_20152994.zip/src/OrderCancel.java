import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;

import javax.swing.JOptionPane;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class OrderCancel implements Runnable{

	private Integer cNum;
	private String oDate;
	private String oMenu;
	private JSONObject cObj;
	private JSONArray cArr;
	
	public OrderCancel(int cNum, String oDate, String oMenu){
		this.cNum = cNum;
		this.oDate = oDate;
		this.oMenu = oMenu;
	}
	
	public synchronized void cancel(){
		boolean isExist = false;
		try{
		JSONParser parser = new JSONParser();
		File f = new File("custom.txt");
		
		if(f.isFile()){
			FileReader reader = new FileReader(f);
			int readed = reader.read();
			if(readed == 0 || readed == -1){
				throw new MyException("������ ������ ������ �����ϴ�.",9);
			}else{
				String json = new String(Files.readAllBytes(Paths.get("custom.txt")));
				JSONObject fObj = (JSONObject) parser.parse(json);
				JSONArray fArr = (JSONArray) fObj.get("customers");
				for(int i=fArr.size()-1; i>=0; i--){
					JSONObject jsonObj = new JSONObject();
					jsonObj = (JSONObject)fArr.get(i);
					
					if(jsonObj.get("cNum").toString().equals(cNum.toString())){
						
						Integer tempAccum = Integer.parseInt(jsonObj.get("cAccum").toString());
						if(tempAccum >= 1){
							((HashMap) fArr.get(i)).replace("cAccum",tempAccum-1);
						}else{
							((HashMap) fArr.get(i)).replace("cAccum",0);
						}
						
						JSONArray tempArr = new JSONArray();
						tempArr = (JSONArray) jsonObj.get("cOrders");
						for(int j=tempArr.size()-1; j>=0; j--){
							JSONObject tempObj = new JSONObject();
							tempObj = (JSONObject) tempArr.get(j);
							
							if(tempObj.get("oDate").toString().equals(oDate) && tempObj.get("oMenu").toString().equals(oMenu)){
								isExist = true;
								String tempMenu = tempObj.get("oMenu").toString();
								tempArr.remove(j);
								((HashMap) fArr.get(i)).replace("cOrders",tempArr);
								Thread t = new BasicMessageBox(jsonObj.get("cNum").toString()+"�� ������ ������ �ֹ�����\n"+tempMenu+"\n"+oDate);
								t.start();
								break;
							}
						}
					}
				}
				
				if(!isExist){ // ã�� �ֹ� ������ �������� �ʴ� ���
					throw new MyException("ã�� �ֹ� ������ �����ϴ�.",5);
				}else{
					JSONObject customers = new JSONObject();
					customers.put("customers", fArr);
					FileWriter writer = new FileWriter(f);
					writer.write(customers.toJSONString());
					writer.flush();
					writer.close();
				}
				
			}
					
		}else{
			throw new MyException("�˻��� ������ �����ϴ�.",8);
		}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (MyException e) {
			Thread t = new WarningMessageBox(e.getMessage());
			t.start();
		}
	}
	
	@Override
	public void run() {
		cancel();
	}

}
