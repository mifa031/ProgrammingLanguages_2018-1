import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class OrderCheck implements Runnable{
	Date sDate, eDate, tDate;
	int kimbap=0, ttukboki=0, sundae=0, odeng=0, tigim=0;
	SimpleDateFormat dt = new SimpleDateFormat("yyyy/MM/dd");
	
	OrderCheck(Date startDate, Date endDate){
		sDate = startDate;
		eDate = endDate;
	}
	
	void check(){
		try{
			JSONParser parser = new JSONParser();
			File f = new File("custom.txt");
			
			if(f.isFile()){
				FileReader reader = new FileReader(f);
				int readed = reader.read();
				if(readed == 0 || readed == -1){
					throw new MyException("������ ������ ������ �����ϴ�.",9);
				}else{
					String json = new String(Files.readAllBytes(Paths.get("custom.txt")));
				    JSONObject fObj = (JSONObject) parser.parse(json);
				    JSONArray fArr = (JSONArray) fObj.get("customers");
				    for(int i=fArr.size()-1; i>=0; i--){ // ���� ����� ��ȸ�ϴ� loop
						JSONObject jsonObj = new JSONObject();
						jsonObj = (JSONObject)fArr.get(i);
						JSONArray tempArr = new JSONArray();
						tempArr = (JSONArray) jsonObj.get("cOrders");
						for(int j=tempArr.size()-1; j>=0; j--){ // �� ������ �ֹ� ����� ��ȸ�ϴ� loop
							JSONObject tempObj = new JSONObject();
							tempObj = (JSONObject) tempArr.get(j);
							tDate = dt.parse(tempObj.get("oDate").toString());
							if(sDate.compareTo(tDate) <= 0 && eDate.compareTo(tDate) >= 0) {
								if(tempObj.get("oMenu").toString().equals("���")) {
									kimbap++;
								}else if(tempObj.get("oMenu").toString().equals("������")) {
									ttukboki++;
								}else if(tempObj.get("oMenu").toString().equals("����")) {
									sundae++;
								}else if(tempObj.get("oMenu").toString().equals("����")) {
									odeng++;
								}else if(tempObj.get("oMenu").toString().equals("Ƣ��")) {
									tigim++;
								}
							}
						}
					}
			   }
			}else{
				throw new MyException("�˻��� ������ �����ϴ�.",8);
			}
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (MyException e) {
			Thread t = new WarningMessageBox(e.getMessage());
			t.start();
		} catch (java.text.ParseException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void run() {
		check();
	}

}
