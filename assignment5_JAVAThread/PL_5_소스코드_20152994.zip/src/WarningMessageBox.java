import javax.swing.JOptionPane;

public class WarningMessageBox extends Thread{
	String message;
	
	WarningMessageBox(String message){
		this.message = message;
	}
	
	@Override
	public void run() {
		JOptionPane.showMessageDialog(null, message, "Error", JOptionPane.ERROR_MESSAGE);
	}
}
